Author: Ahmed Eid Buradhah

Aug 3, 2020

-------------------------------

* To run my classes please create a new project in Eclipse or open the file attached. 

* Run each class by itself.

* Each class assigned with the question related to. 

* compile the programs. 

--------------------------------