/*
 *
 * Ahmed Eid Buradhah
 */

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Questions4 {

	public static void main(String[] args) {
		// an array to holds an int numbers
			int[] arr = {10, -4, 8, 0, -4, -4, -4, 8, 2, -4, 6, 6, 10, 10, 6};
			
			// call the method
			printUniqueNumber(arr);
		
		}
	
// a method that print the unique number and count how many they accrue in the array
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static void printUniqueNumber(int[] arr) {
		boolean[] arr1 = new boolean[arr.length];
		Arrays.fill(arr1, false);
		Set set = new HashSet();
		int counter = 0;
		for (int i = 0; i < arr.length; i++) {
			if(arr1[i] == false) {
				counter = 0;
			for(int j = 0; j < arr.length; j++) {
				if(arr[i] == arr[j]) 	{
					counter++;
					arr1[j] = false;
				}
			}
		}
	if(set.add(arr[i])) {		
   System.out.print( " { " + arr[i]+ " : " + counter + " } ");
	}
		}
}
}
