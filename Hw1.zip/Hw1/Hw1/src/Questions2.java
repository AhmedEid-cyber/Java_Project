/*
 * 
 * 
 * Ahmed Eid Buradhah
 */

public class Questions2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	// array holds the number positive and negative
		int[] arr = {10,-20,30,-40,50,-60,70,-80,90,-100,110};

		// print the output from the method
		printPositiveNumber(arr);
		
	}
	// method to print the positive number only
	private static void printPositiveNumber(int[] arr) {
		// a loop goes throw the array
		for (int i = 0; i < arr.length; i++) {
			// pick the numbers that are grater than 0
			if(arr[i] > 0)
				// print the number
			System.out.println(arr[i] + " ");
		}
	}
}

