/*
 *
 * 
 * Ahmed Eid Buradhah
 */
public class Questions1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//declare the first array
		char[] firstArray = {'a','b','c','d'};
		// declare the second array
		char[] secondArray = {'e','f','g','h'};

		// print the result
		System.out.println(findCommonElement(firstArray,secondArray));
		
	}
	
	// a method that check if the two array are similar or different
	// if they are similar the result going to be true
	// if they are different the result going to be false

	private static boolean findCommonElement(char[] firstArray, char[] secondArray) {
		// TODO Auto-generated method stub
		// a loop that goes throw the first array
		for(int i = 0; i < firstArray.length; i++) {
			// a loop that goes throw the second array
			for(int j = 0; j < secondArray.length; j++) {
				// check if there is a similarity between the two arrays
				if(firstArray[i] == secondArray[j]) {
					// if there are a similarity will return true
					return true;
				}
			}
		}
		// if there are no similarity will return false
		return false;
		
	}
	

}

