/*
 * 
 * 
 * Ahmed Eid Buradhah
 */

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Questions3 {

	public static void main(String[] args) {
		
		// an array that holds the int number
			int[] arr = {10, 70, 20, 30, 30, 30, 10, 70, 20};
			
			// call the method
			printUniqueNumber(arr);
		
		}
	
// a method that print the unique number from the array
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static void printUniqueNumber(int[] arr) {
		boolean[] arr1 = new boolean[arr.length];
		Arrays.fill(arr1, false);
		Set set = new HashSet();
		for (int i = 0; i < arr.length; i++) {
			if(arr1[i] == false) {
			for(int j = 0; j < arr.length; j++) {
				if(arr[i] == arr[j]) 	{
					arr1[j] = false;
				}
			}
		}
	if(set.add(arr[i])) {		
   System.out.print(arr[i]+ " ");
	}
		}
}
}
