//DON'T UNCOMMENT THE FOLLOWING THREE LINES.
//[46145818]
//[Ahmed Eid Buradhah] (as on eStudent)
//[X] Declaration from student that they haven't viewed another person's code for this assignment. 
//(Add a x between the brackets)

package shopping;

import java.math.BigDecimal;

public class CartItem {
	public StockItem item;
	public int quantity;
	public int discountPercentage;
	
	/**
	 * 
	 * @param it for item
	 * @param q for quantity (set the higher of 0 and q to quantity)
	 * set discountPercentage to 0
	 */
	public CartItem(StockItem it, int q) {
            item=it;
            quantity=q;
            discountPercentage=0;
            
	}
	
	/**
	 * 
	 * @param it for item, assume its not null
	 * @param q for quantity (set the higher of 0 and q to quantity)
	 * @param discount (constrain discount between 0 and 100 before copying into discountPercentage).
	 * for example, 
	 * if discount = -5, discountPercentage should become 0
	 * if discount = 12, discountPercentage should become 12
	 * if discount = 150, discountPercentage should become 100
	 */
	public CartItem(StockItem it, int q, int discount) {
            item=it;
            quantity=q;
            
            if(discount<0){
            discountPercentage=0;
            }
            else if(discount>100){
            discountPercentage=100;
            }
            else{
            discountPercentage=discount;
            }
	}

	/**
	 * 
	 * @return the total cost of the item (after discounting if so)
	 * for example,
	 * if the unitPrice of item is 1.5, quantity is 3, discountPercentage is 0, return 4.5
	 * if the unitPrice of item is 1.5, quantity is 3, discountPercentage is 20, return 3.6
	 */
	public double totalCost() {
            double total = (item.unitPrice*quantity);
            
            if(discountPercentage!=0) {
            total -= (discountPercentage * total) / 100
            		;
            }
            return total;
	}
	
	/**
	 * 
	 * @return the discount value per unit
	 * for example, 
	 * if the unitPrice of item is 1.5 and discountPercentage is 20, return 0.3
	 */
	public double getDiscountPerUnit() {
			if(discountPercentage == 0)
			return 0;
			else {
            double disc = (item.unitPrice * discountPercentage) / 100;
            return disc;
			}
	}
	
	
	/**
	 * 
	 * @return the discounted price for the calling object.
	 * for example, if unitPrice = 2.4, discountPercentage = 10, return 2.16
	 */
	public double getDiscountedUnitPrice() {
            double price = item.unitPrice - (discountPercentage*item.unitPrice)/100;
            return price;
	}
	
	/**
	 * 
	 * @return total discount for this item
	 * for example, if unitPrice = 2.4, quantity = 4, discountPercentage = 10, return 0.96
	 */
	public double getTotalDiscount() {
            double totalDisc = (discountPercentage*item.unitPrice*quantity)/100;
            return totalDisc;
	}
	
	/**
	 * @param other
	 * @return
	 * 1 if calling object is "more than" parameter object
	 * -1 if calling object is "less than" parameter object
	 * 0 if calling object is "equal to" parameter object
	 * 
	 * IMPORTANT!!! 
	 * Ordering criterion: 
	 * First: StockItem instance variable (item)
	 * Second: Discount percentage
	 */
	public int compareTo(CartItem other) {
            if(item.compareTo(other.item)==1){
            return 1;
            }
            else if (item.compareTo(other.item)==-1){
            return -1;
            }
            else if (item.compareTo(other.item)==0){
                if(discountPercentage>other.discountPercentage){
                    return 1;
                }
                else if(discountPercentage<other.discountPercentage){
                    return -1;
                }
                else if(discountPercentage==other.discountPercentage){
                return 0;
                }
            }
            return 0;
	}
	
	/**
	 * return String version of the item
	 * for example,
	 * if item represents name = "BIBS", unitPrice = 5.9, quantity = 6, discountPercentage = 0,
	 * 		return "BIBS (6 @ $5.9)"
	 * if item represents name = "BIBS", unitPrice = 5.9, quantity = 6, discountPercentage = 10,
	 * 		return "BIBS (6 @ *$5.31)"
	 */
        
	public String toString() {
	
        if(discountPercentage==0){
        	String s = item.unitPrice+"";
        	String ss[] = s.split("\\.");
        	if(ss[1].length() > 2) {
        		String tmp = new BigDecimal(String.valueOf(item.unitPrice)).setScale(2, BigDecimal.ROUND_FLOOR)+"";
        		return item.name + " (" +quantity+" @ $"+tmp+")";
        	}
        	else if(ss[1].equals("0")) {
        		return item.name + " (" +quantity+" @ $"+ss[0]+")";
        	}
        	else {
        		return item.name + " (" +quantity+" @ $"+item.unitPrice+")";
        	}
        }
        else {
        	String s = (item.unitPrice - ((discountPercentage*item.unitPrice)/100)) + "";
        	String[] ss = s.split("\\.");
        	if(ss[1].length() > 2) {
        		String tmp = String.format("%.2f", (item.unitPrice - ((discountPercentage*item.unitPrice)/100)));
        		return item.name + " (" +quantity+" @ *$"+tmp+")";
        	}
        	else if(ss[1].equals("0")) {
        		return item.name + " (" +quantity+" @ *$"+ss[0]+")";
        	}
        	else {
        		return item.name + " (" +quantity+" @ *$"+(item.unitPrice - ((discountPercentage*item.unitPrice)/100))+")";
        	}
    	}
	}
}
