package passingAnalytics.tests;


import java.io.*;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import passingAnalytics.toBeSubmitted.*;
import passingAnalytics.others.*;

@SuppressWarnings("unused")
public class PassStatsTest{
	public static int score = 0;
	public static String result = "";
	public static String currentMethodName = null;
	ArrayList<String> methodsPassed = new ArrayList<String>();
	
	PassStats stats1, stats2, stats3;

	@Before
	public void setUp() throws Exception {
		currentMethodName = null;
		stats1 = new PassStats("in1.csv");
		stats2 = new PassStats("in2.csv");
		stats3 = new PassStats("in3.csv");
	}

	@Test @Graded(description="PassStats:countSuccessfulPasses()", marks=5)
	public void testCountSuccessfulPasses() {
		assertEquals(408, stats1.countSuccessfulPasses());
		assertEquals(398, stats2.countSuccessfulPasses());
		assertEquals(402, stats3.countSuccessfulPasses());

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="PassStats:countPassesInSegment(int)", marks=5)
	public void testCountPassesInSegment() {
		assertEquals(143, stats1.countPassesInSegment(0));
		assertEquals(175, stats1.countPassesInSegment(1));
		assertEquals(56, stats1.countPassesInSegment(2));
		assertEquals(61, stats1.countPassesInSegment(3));
		assertEquals(180, stats2.countPassesInSegment(0));
		assertEquals(180, stats2.countPassesInSegment(1));
		assertEquals(55, stats2.countPassesInSegment(2));
		assertEquals(52, stats2.countPassesInSegment(3));
		
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="PassStats:countSuccessfulForwardPasses()", marks=5)
	public void testCountSuccessfulForwardPasses() {
		assertEquals(216, stats1.countSuccessfulForwardPasses());
		assertEquals(203, stats2.countSuccessfulForwardPasses());
		assertEquals(200, stats3.countSuccessfulForwardPasses());
		
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();		
	}

	@Test @Graded(description="PassStats:countSuccessfulSwitches()", marks=5)
	public void testCountSuccessfulSwitches() {
		assertEquals(86, stats1.countSuccessfulSwitches());
		assertEquals(74, stats2.countSuccessfulSwitches());
		assertEquals(79, stats3.countSuccessfulSwitches());
		
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();		
	}

	@Test @Graded(description="PassStats:countSuccessfulLongBalls()", marks=5)
	public void testCountSuccessfulLongBalls() {
		assertEquals(55, stats1.countSuccessfulLongBalls());
		assertEquals(50, stats2.countSuccessfulLongBalls());
		assertEquals(60, stats3.countSuccessfulLongBalls());

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="PassStats:countSuccessfulPassesInSegment(int)", marks=5)
	public void testCountSuccessfulPassesInSegment() {
		assertEquals(133, stats1.countSuccessfulPassesInSegment(0));
		assertEquals(162, stats1.countSuccessfulPassesInSegment(1));
		assertEquals(53, stats1.countSuccessfulPassesInSegment(2));
		assertEquals(60, stats1.countSuccessfulPassesInSegment(3));
		assertEquals(160, stats2.countSuccessfulPassesInSegment(0));
		assertEquals(150, stats2.countSuccessfulPassesInSegment(1));
		assertEquals(44, stats2.countSuccessfulPassesInSegment(2));
		assertEquals(44, stats2.countSuccessfulPassesInSegment(3));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="PassStats:successfulPassPercentage()", marks=5)
	public void testSuccessfulPassPercentage() {
		assertEquals(93.7931, stats1.successfulPassPercentage(), 0.01);
		assertEquals(85.2248, stats2.successfulPassPercentage(), 0.01);
		assertEquals(83.4024, stats3.successfulPassPercentage(), 0.01);
		
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="PassStats:successfulPassPercentageInSegment(int)", marks=5)
	public void testSuccessfulPassPercentageInSegment() {
		assertEquals(88.8888, stats2.successfulPassPercentageInSegment(0), 0.01);
		assertEquals(83.3333, stats2.successfulPassPercentageInSegment(1), 0.01);
		assertEquals(80, stats2.successfulPassPercentageInSegment(2), 0.01);
		assertEquals(84.6153, stats2.successfulPassPercentageInSegment(3), 0.01);
		assertEquals(86.5168, stats3.successfulPassPercentageInSegment(0), 0.01);
		assertEquals(85.2631, stats3.successfulPassPercentageInSegment(1), 0.01);
		assertEquals(71.6666, stats3.successfulPassPercentageInSegment(2), 0.01);
		assertEquals(79.6296, stats3.successfulPassPercentageInSegment(3), 0.01);

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="PassStats:successfulPassCountInSegments()", marks=5)
	public void testSuccessfulPassCountInSegments() {
		assertEquals("[133, 162, 53, 60]", stats1.successfulPassCountInSegments().toString());
		assertEquals("[160, 150, 44, 44]", stats2.successfulPassCountInSegments().toString());
		assertEquals("[154, 162, 43, 43]", stats3.successfulPassCountInSegments().toString());

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="PassStats:longestPassIndex()", marks=5)
	public void testLongestPassIndex() {
		assertEquals(244, stats1.longestPassIndex());
		assertEquals(105, stats2.longestPassIndex());
		assertEquals(407, stats3.longestPassIndex());

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}
	
	@After
	public void logSuccess() throws NoSuchMethodException, SecurityException {
		if(currentMethodName != null && !methodsPassed.contains(currentMethodName)) {
			methodsPassed.add(currentMethodName);
			Method method = getClass().getMethod(currentMethodName);
			Graded graded = method.getAnnotation(Graded.class);
			score+=graded.marks();
			result+=graded.description()+" passed. Marks awarded: "+graded.marks()+"\n";
		}
	}
	
	@AfterClass
	public static void wrapUp() throws IOException {
		if(result.length() != 0) {
			result = result.substring(0, result.length()-1); //remove the last "\n"
		}
		System.out.println(result);
		System.out.println("Indicative mark for PassStats.java: "+score);
		System.out.println();
	}
}
