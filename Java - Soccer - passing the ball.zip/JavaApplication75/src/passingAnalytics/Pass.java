package passingAnalytics.toBeSubmitted;

import passingAnalytics.others.Time;

public class Pass {
	public Position from, to; //the pass is made from "from" Position, to "to" Position
	public Time timestamp; //time at which the pass is made
	public boolean completed; //true indicates pass successful, false indicates great shame

	/**
	 * 
	 * @param loc1: from
	 * @param loc2: to
	 * @param t: timestamp
	 * @param outcome: completed
	 */
	public Pass(Position loc1, Position loc2, Time t, boolean outcome) {
		//to be completed 
                this.from=loc1;
                this.to=loc2;
                this.timestamp=t;
                this.completed=outcome;
	}

	/**
	 * 
	 * @return the distance of the pass
	 */
	public double distance() {
            
            ///calcualte relative x,y distances from start to end point
            int distanceX = (to.x-from.x);
            int distanceY = (to.y-from.y);
            
            ///calculate the length to dx,dy
            return Math.sqrt(distanceX*distanceX+distanceY*distanceY);
	}

	/**
	 * 
	 * @return true if its a successful forward pass, false otherwise
	 */
	public boolean isSuccessfulForwardPass() {
            
            ///pass is both completed and from y coord is less than to y coord
		return completed && (from.y<to.y);
	}

	/**
	 * 
	 * @return true if its a successful switch, false otherwise
	 */
	public boolean isSuccessfulSwitch() {
            
            ///if the pass is not completed it cannot be sucesfull
            if(!completed)
                return false;
            
            //if from is left and to is right
            if((from.getWing()==-1 && to.getWing()==+1))
               return true;
            
            //if from is right and to is left
            if((from.getWing()==+1 && to.getWing()==-1))
               return true;
            
            ///else it is not a switch, return fasle
		return false;
	}
	
	/**
	 * 
	 * @return true if it's an attempted long ball (forward pass at least 
	 * with y difference half the field length or more), false otherwise
	 */
	public boolean isLongBall() {
            
            //distance of pass
            int distanceY = (to.y-from.y);
            
            //return true if more or equalto half length
            return distanceY>=Position.HALF_LENGTH;
	}

	//DO NOT MODIFY
	public String toString() {
		if(completed) {
			if(from.y < to.y) {
				return "Successful,Forward,"+from+","+to+","+timestamp;
			}
			else {
				if(from.y > to.y) {
					return "Successful,Backward,"+from+","+to+","+timestamp;
				}
				else {
					return "Successful,Sideways,"+from+","+to+","+timestamp;
				}
			}
		}
		else { 
			if(from.y < to.y) {
				return "Unsuccessful,Forward,"+from+","+to+","+timestamp;
			}
			else {
				if(from.y > to.y) {
					return "Unsuccessful,Backward,"+from+","+to+","+timestamp;
				}
				else {
					return "Unsuccessful,Sideways,"+from+","+to+","+timestamp;
				}
			}
		}
	}

	
	//YOU ARE FREE TO ADD MORE PRIVATE, OR PUBLIC, METHODS	
}
