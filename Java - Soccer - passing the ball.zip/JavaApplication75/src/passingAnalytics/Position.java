package passingAnalytics.toBeSubmitted;

/**
 * 
 * @author gauravgupta
 * the class represents the location of a player on the pitch.
 * (0, 0) represents center of the pitch (from where kickoff happens).
 * IMPORTANT: We assume home team is near side,
 * (-BREADTH/2, -LENGTH/2) represents leftmost point on defensive goal-line.
 * (BREADTH/2, -LENGTH/2) represents rightmost point on defensive goal-line.
 * (-BREADTH/2, LENGTH/2) represents leftmost point on opposition goal-line.
 * (BREADTH/2, LENGTH/2) represents rightmost point on opposition goal-line.
 * 
 * See figure provided with specs if not clear
 */
public class Position {
	public static final int LENGTH = 100;
	public static final int BREADTH = 60;
	public static final int HALF_LENGTH = LENGTH/2;
	public static final int HALF_BREADTH = BREADTH/2;
	
	public int x, y;
	
	/**
	 * 
	 * @param _x: for instance variable x
	 * @param _y: for instance variable y
	 * 
	 * ensure the values provided are in valid range.
	 * if less than the minimum possible value, assign the minimum possible value to the instance variable.
	 * if more than the maximum possible value, assign the maximum possible value to the instance variable.
	 * See tests for input-output mappings if you don't understand the description.
	 */
	public Position(int _x, int _y) {
		
                //limit positions
                if(_x<-HALF_BREADTH)_x=-HALF_BREADTH;
                if(_x>+HALF_BREADTH)_x=+HALF_BREADTH;
                
                if(_y<-HALF_LENGTH)_y=-HALF_LENGTH;
                if(_y>+HALF_LENGTH)_y=+HALF_LENGTH;
                
                x=_x;
                y=_y;
	}
	
	/**
	 * 
	 * @return distance of the current position from the goalie
	 * who's assumed to be at (0, -HALF_LENGTH)
	 */
	public double distanceFromHomeGoalie() {
            
            ///calculate relative x/y distances to goalie pos
            
            int goalieX = 0;
            int goalieY = -HALF_LENGTH;
            
            int distanceX = (x-goalieX);
            int distanceY = (y-goalieY);
            
            return Math.sqrt(distanceX*distanceX+distanceY*distanceY);
	}
	
	/**
	 * 
	 * @return
	 * -1 if on the left wing
	 * 1 if on the right wing
	 * 0 in all other cases.
	 * 
	 * see specs for definition of left, middle and right wings
	 */
	public int getWing() {
            
            /// central part will take from -HALF_BREADTH/3 to + HALF_BREADTH/3
            /// left and right parts are wings
            
            //left wing if less than -HALF_BREADTH/3
            if(x<-HALF_BREADTH/3)
		return -1;
            
            //right wing if greater than HALF_BREADTH/3
            if(x>+HALF_BREADTH/3)
		return 1;
            
            //else center
		return 0;
	}
	
	/**
	 * 
	 * @param other
	 * @return 
	 * 1 if calling object further from home goalie than parameter object
	 * -1 if calling object closer to home goalie than parameter object
	 * 0 in all other cases
	 */
	public int compareTo(Position other) {
            //calculate calling object and otehr object distances
            double distance=distanceFromHomeGoalie();
            double otherDistance=other.distanceFromHomeGoalie();
            
            //if own is furher return 1
            if(distance>otherDistance)
                return 1;
            
            //of other is further return -1
            if(distance<otherDistance)
                return -1;
            
            //else they are same
		return 0;
	}
	
	//DO NOT MODIFY
	public String toString() {
		return x+","+y;
	}
	
	//YOU ARE FREE TO ADD MORE PRIVATE, OR PUBLIC, METHODS	
}
