package passingAnalytics.toBeSubmitted;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import passingAnalytics.others.Reader;

public class PassStats {

    public ArrayList<Pass> data; //this is the all-important collection on which all your methods will operate

    //DO NOT MODIFY
    public PassStats() {
        data = new ArrayList<Pass>();
    }

    //DO NOT MODIFY
    public PassStats(ArrayList<Pass> passes) {
        data = passes;
    }

    /**
     * DO NOT MODIFY
     *
     * This constructor calls Reader.readFrom(String) that in turn reads the
     * list of passes from the csv file and returns the ArrayList of Pass
     * objects.
     *
     * The returned list is copied in the instance variable "data" by the
     * constructor
     *
     * @param filename
     * @throws FileNotFoundException
     */
    public PassStats(String filename) throws FileNotFoundException {
        data = Reader.readFrom(filename);
        //details of all the passes is already in data

        //data.get(0) gives the details of the first pass
        //data.get(data.size()-1) gives the details of the last pass
        //data.get(0).completed tells us if the first pass was successful
        //data.get(0).from.y gives the y coordinate of the origin of the first pass
        //data.get(0).to.y gives the y coordinate of the intended destination of the first pass
        //using data.get(0).from.y, data.get(0).to.y; you can determine 
        //if the first pass was made forward, back or sideways
    }

    //DO NOT MODIFY
    public int countPasses() {
        return data.size();
    }

    /**
     *
     * @return number of successful (completed) passes
     */
    public int countSuccessfulPasses() {

        //counter for passes
        int count = 0;

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            ///increment on sucesfull pass
            if (pass.completed) {
                count++;
            }
        }

        return count;
    }

    /**
     *
     * @param seg
     * @return number of passes in the passed segment
     */
    public int countPassesInSegment(int seg) {
        //counter for passes
        int count = 0;

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            //count if segment of timetam equal the segment parameter
            if (pass.timestamp.segment == seg) {
                count++;
            }
        }

        return count;
    }

    /**
     *
     * @return number of successful "forward" passes (up the field). see the
     * specs for definition of a forward pass.
     */
    public int countSuccessfulForwardPasses() {
        //counter for passes
        int count = 0;

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            ///if completed and to y is greater than from y its forward
            if (pass.completed && pass.from.y < pass.to.y) {
                count++;
            }
        }

        return count;
    }

    /**
     *
     * @return number of successful "switches". see the specs for definition of
     * a switch.
     */
    public int countSuccessfulSwitches() {
        //counter for passes
        int count = 0;

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            ///if completed
            if (pass.completed
                    && ((pass.from.getWing() == +1 && pass.to.getWing() == -1)
                    || (pass.from.getWing() == -1 && pass.to.getWing() == +1))) {
                count++;
            }
        }

        return count;
    }

    /**
     *
     * @return number of successful "long balls". see the specs for definition
     * of a long ball.
     */
    public int countSuccessfulLongBalls() {
        int count = 0;

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);

            ///if completed and long ball
            if (pass.completed && pass.isLongBall()) {
                count++;
            }
        }

        return count;
    }

    /**
     *
     * @param seg
     * @return number of successful passes in passed segment.
     */
    public int countSuccessfulPassesInSegment(int seg) {
        //counter for passes
        int count = 0;

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            //count if completed and segment of timetam equal the segment parameter
            if (pass.completed && pass.timestamp.segment == seg) {
                count++;
            }
        }

        return count;
    }

    /**
     *
     * @return percentage of passes made that were successful (completed).
     * return 0 if no passes were made.
     */
    public double successfulPassPercentage() {
        int successful = countSuccessfulPasses();
        int total = countPasses();

        ///return 0 if no passes
        if (total == 0) {
            return 0;
        }

        //else calculate percent, use 100.0 so we do floating point math
        return successful * 100.0 / total;
    }

    /**
     *
     * @param seg
     * @return percentage of passes made that were successful (completed) in
     * passed segment. return 0 if no passes were made in the given segment.
     */
    public double successfulPassPercentageInSegment(int seg) {
        int successful = countSuccessfulPassesInSegment(seg);
        int total = countPassesInSegment(seg);

        ///return 0 if no passes
        if (total == 0) {
            return 0;
        }

        //else calculate percent, use 100.0 so we do floating point math
        return successful * 100.0 / total;
    }

    /**
     *
     * @return a list containing number of successful passes in the 4 segments
     * (in chronological order).
     */
    public ArrayList<Integer> successfulPassCountInSegments() {
        ArrayList<Integer> passesInSegments = new ArrayList<Integer>();
        //add passes in the 4 segments to the array list
        passesInSegments.add(countSuccessfulPassesInSegment(0));
        passesInSegments.add(countSuccessfulPassesInSegment(1));
        passesInSegments.add(countSuccessfulPassesInSegment(2));
        passesInSegments.add(countSuccessfulPassesInSegment(3));
        return passesInSegments;
    }

    /**
     *
     * @return index of the longest pass (assume at least one pass has been
     * made) return the first of the passes in case of a tie
     */
    public int longestPassIndex() {

        int longestIndex = 0;
        double longestDist = 0;

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            double dist = pass.distance();

            //if distance is greater that current longest distance
            //set this as longest pass and update longest distance
            if (dist > longestDist) {
                longestIndex = i;
                longestDist = dist;
            }
        }

        return longestIndex;
    }

    /**
     * D
     *
     * @return a list containing the longest consecutive sequence of successful
     * forward passes. So, if at most 8 successful forward passes were made in a
     * row, return a list containing those passes (in order of execution).
     *
     * in case of a tie, return the first sequence (in order of execution).
     */
    public ArrayList<Pass> longestSuccessfulForwardPassSequence() {

        ArrayList<Pass> longestSequence = new ArrayList<Pass>();
        ArrayList<Pass> currentSequence = new ArrayList<Pass>();

        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            //if successsful forwad pa add to current list
            if (pass.isSuccessfulForwardPass()) {
                currentSequence.add(pass);
            } else {
                //else if current list was longer thatn the best one
                //save it as best one

                if (currentSequence.size() > longestSequence.size()) {
                    longestSequence = currentSequence;
                }

                //and start a new empty list
                currentSequence = new ArrayList<Pass>();
            }
        }

        if (currentSequence.size() > longestSequence.size()) {
            longestSequence = currentSequence;
        }

        return longestSequence;
    }

    /**
     * D/HD
     *
     * @param n
     * @return the maximum ground gained (defined as the increase in y position)
     * over a MAXIMUM of n consecutive passes. during the course of the n
     * passes, if any pass is unsuccessful, the ground gained is reset to 0. you
     * should return the highest of the sub-gains in such a situation.
     *
     * For example, say the following list represents the ground gained in each
     * pass, a cap (^) representing an unsuccessful pass:
     *
     * [40, -20, 90, ^60, 30, 40, 30, 20, -10, 50, 30]
     *
     * if n = 4, return 120 (30+40+30+20) if n = 2, return 90 (since on it's
     * own, the third pass gained 90 yards)
     *
     * See input-output mappings in tests if you don't understand the
     * description
     */
    public int maxGroundGained(int n) {
        int mostGainedDistance = 0;
        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            int currentGainedDistance = 0;
            //test the sequence of up to n passes starting at current position
            for (int j = 0; i + j < data.size() && j < n; j++) {
                Pass pass = data.get(i + j);
                if (!pass.completed) {//if not successfull stop
                    break;
                } else {//successful pass
                    //add the distance gained by this pass
                    currentGainedDistance += pass.to.y - pass.from.y;

                    //if e got better than current best updae best
                    if (currentGainedDistance > mostGainedDistance) {
                        mostGainedDistance = currentGainedDistance;
                    }
                }
            }
        }

        return mostGainedDistance;
    }

    /**
     * HD
     *
     * @return a list of list of passes such that each list contains the longest
     * consecutive sequence of successful forward passes. So, if at most 5
     * successful forward passes were made in a row on three separate and
     * non-overlapping occasions, return a list containing three lists, each
     * containing the 5 passes (in order of execution).
     *
     * As an example, let 1 represent a successful forward pass, and 0 anything
     * else. Let the pass sequence be [0,0,1,1,0,0,1,1,0,0,1,0,1,1]
     *
     * You should return an arraylist containing three arraylists of Pass
     * object. First sublist contains passes at indices 2 and 3 Second sublist
     * contains passes at indices 6 and 7 Third sublist contains passes at
     * indices 12 and 13
     */
    public ArrayList<ArrayList<Pass>> longestSuccessfulForwardPassSequences() {
        ArrayList<ArrayList<Pass>> longestSequences = new ArrayList<ArrayList<Pass>>();
        ArrayList<Pass> currentSequence = new ArrayList<Pass>();
        int maxPasses = 0;
        //iterate over all passes
        for (int i = 0; i < data.size(); i++) {
            Pass pass = data.get(i);
            if (!pass.isSuccessfulForwardPass()) {//if not stop adding to list and prepare ne list
                currentSequence = new ArrayList<Pass>();
                break;
            } else {//successful pass
                //add to current list
                currentSequence.add(pass);

                ///list got longer than maximum,
                //remove all ohers and add this one only
                if (currentSequence.size() > maxPasses) {
                    maxPasses = currentSequence.size();
                    longestSequences.clear();
                    longestSequences.add(currentSequence);
                } else if (currentSequence.size() == maxPasses) {///current list is same length as maximum length list we have seen,
                    //so ad it to list of maximum length passes
                    longestSequences.add(currentSequence);
                }
            }
        }

        return longestSequences;
    }

    //YOU ARE FREE TO ADD MORE PRIVATE, OR PUBLIC, METHODS	
}
